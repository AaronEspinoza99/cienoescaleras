#include <iostream>
#include "juego.h"
#include "menu.h"
#include "rlutil.h"
#include "dados.h"
using namespace std;


int puntuacionAlta = 0;
string nombrePuntuacionAlta = "";



///calcular el puntaje segun las combinaciones
int calcularPuntaje(int dados[]) {
    int contador[7] = {0}; // Contador para cada valor de dado (1-6)
    for (int x = 0; x < 6; x++) {
        contador[dados[x]]++;
    }

    /// Verificamos si es escalera (1, 2, 3, 4, 5, 6)
    if (contador[1] == 1 && contador[2] == 1 && contador[3] == 1 &&
        contador[4] == 1 && contador[5] == 1 && contador[6] == 1) {
        cout << "Hiciste ESCALERA! Felicitaciones, ganaste la partida." << endl;
        return 100; // Gana la partida
    }

    /// Verificamos si hay un sexteto de 6-- (6 veces el valor 6)
    if (contador[6] == 6) {
        cout << "Sexteto de 6! Puntaje reseteado a 0." << endl;
        return 0; // Puntaje reseteado
    }

    /// Verificamos si hay un sexteto (6 dados iguales)
    for (int x = 1; x <= 6; x++) {
        if (contador[x] == 6) {
            cout << "Sexteto de " << x << " -> " << x * 10 << " puntos." << endl;
            return x * 10;
        }
    }

    /// Si no hay combinaciones especiales, sumar los valores de los dados
    int suma = 0;
    for (int x = 0; x < 6; x++) {
        suma += dados[x];
    }
    cout << "Suma de dados: " << suma << " puntos." << endl;
    return suma;
}

/// Funcion para actualizar la puntuacion mas alta
void actualizarPuntuacionAlta(const string& nombre, int puntaje) {
    if (puntaje > puntuacionAlta) {
        puntuacionAlta = puntaje;
        nombrePuntuacionAlta = nombre;
    }
}


/// Funcion para mostrar la puntuacion mas alta
void mostrarPuntuacionAlta() {
    if (puntuacionAlta > 0) {
        cout << "Puntuacion mas alta: " << nombrePuntuacionAlta
             << " con " << puntuacionAlta << " puntos." << endl;
    } else {
        cout << "No se ha registrado ninguna puntuacion alta en esta sesion." << endl;
    }
}


void unJugador() {
    string nombre;
    cout << "Ingrese el nombre del jugador: ";
    cin >> nombre;
    int posicionX = 10;
    int posicionY = 5;
    int puntuacionTotal = 0;
    int ronda = 1;

    while (puntuacionTotal < 100) {
        cout << "---- Ronda " << ronda << "----" << endl;
        int puntuacionMaxima = 0;
        int dados[6];

        ///tres lanzamientos por ronda mi rey
        for (int x = 1; x <=3; x++) {
            cout << "Lanzamiento " << x << ":";

            lanzarYDibujarDados(dados, posicionX, posicionY);

            int puntuacion = calcularPuntaje(dados);

            if(puntuacion == 100) {
                cout << nombre << "Felicitaciones, ganaste la partida." << endl;
                actualizarPuntuacionAlta(nombre, puntuacionTotal);
                return;
            }

            if (puntuacion > puntuacionMaxima) {
                puntuacionMaxima = puntuacion;
            }
        }

        ///Actualizamos la puntuacion total
        puntuacionTotal += puntuacionMaxima;
        cout << "Puntuacion de la ronda: " << puntuacionMaxima << endl;
        cout << "Puntuacion total: " << puntuacionTotal << endl;
        ronda++;
        system("pause");
    }

    cout << nombre << " ha ganado la partida con " << puntuacionTotal << " puntos." << endl;
    actualizarPuntuacionAlta(nombre, puntuacionTotal);
}

#include <iostream>
#include "rlutil.h"
#include "dados.h"


using namespace std;

int dados[6];
int posicionX = 10;
int posicionY = 5;

void lanzarYMostrarDados(int dados[], int posicionX, int posicionY) {
    cout << "Dados: ";
    for (int x = 0; x < 6; x++) {
        dados[x] = rand() % 6 + 1; // Generar n�meros entre 1 y 6
        cout << dados[x] << " ";
        dibujarDado(dados[x], posicionX + x * 8, posicionY); // Dibujar cada dado en posiciones separadas
    }
    cout << endl;
}

void dibujarDado(int dado, int posicionX, int posicionY) {
    dibujarCuadrado(posicionX, posicionY); // Dibujar el cuadrado del dado
    dibujarPuntos(dado, posicionX, posicionY); // Dibujar los puntos seg�n el valor del dado
    dibujarSombra(posicionX, posicionY); // Dibujar la sombra del dado
}

void dibujarPuntos(int dado, int posicionX, int posicionY) {
    rlutil::setColor(rlutil::BLACK);
    rlutil::setBackgroundColor(rlutil::WHITE);

    switch (dado) {
        case 1:
            rlutil::locate(posicionX + 3, posicionY + 1);
            cout << (char)254; // Punto en el centro
            break;
        case 2:
            rlutil::locate(posicionX + 1, posicionY);
            cout << (char)220; // Esquina superior izquierda
            rlutil::locate(posicionX + 5, posicionY + 2);
            cout << (char)223; // Esquina inferior derecha
            break;
        case 3:
            rlutil::locate(posicionX + 3, posicionY + 1);
            cout << (char)254; // Centro
            rlutil::locate(posicionX + 1, posicionY);
            cout << (char)220; // Esquina superior izquierda
            rlutil::locate(posicionX + 5, posicionY + 2);
            cout << (char)223; // Esquina inferior derecha
            break;
        case 4:
            rlutil::locate(posicionX + 1, posicionY);
            cout << (char)220; // Esquina superior izquierda
            rlutil::locate(posicionX + 5, posicionY);
            cout << (char)220; // Esquina superior derecha
            rlutil::locate(posicionX + 1, posicionY + 2);
            cout << (char)223; // Esquina inferior izquierda
            rlutil::locate(posicionX + 5, posicionY + 2);
            cout << (char)223; // Esquina inferior derecha
            break;
        case 5:
            rlutil::locate(posicionX + 3, posicionY + 1);
            cout << (char)254; // Centro
            rlutil::locate(posicionX + 1, posicionY);
            cout << (char)220; // Esquina superior izquierda
            rlutil::locate(posicionX + 5, posicionY);
            cout << (char)220; // Esquina superior derecha
            rlutil::locate(posicionX + 1, posicionY + 2);
            cout << (char)223; // Esquina inferior izquierda
            rlutil::locate(posicionX + 5, posicionY + 2);
            cout << (char)223; // Esquina inferior derecha
            break;
        case 6:
            rlutil::locate(posicionX + 1, posicionY);
            cout << (char)220; // Esquina superior izquierda
            rlutil::locate(posicionX + 5, posicionY);
            cout << (char)220; // Esquina superior derecha
            rlutil::locate(posicionX + 3, posicionY);
            cout << (char)220; // Medio superior
            rlutil::locate(posicionX + 1, posicionY + 2);
            cout << (char)223; // Esquina inferior izquierda
            rlutil::locate(posicionX + 5, posicionY + 2);
            cout << (char)223; // Esquina inferior derecha
            rlutil::locate(posicionX + 3, posicionY + 2);
            cout << (char)223; // Medio inferior
            break;
    }
}

void dibujarSombra(int posicionX, int posicionY) {
    rlutil::setColor(rlutil::GREY);
    rlutil::setBackgroundColor(rlutil::BLACK);

    for (int y = posicionY; y <= posicionY + 2; y++) {
        rlutil::locate(posicionX + 7, y);
        if (y == posicionY) {
            cout << (char)220;
        } else {
            cout << (char)219;
        }
    }
    for (int x = posicionX + 1; x <= posicionX + 7; x++) {
        rlutil::locate(x, posicionY + 3);
        cout << (char)223;
    }
}

void dibujarCuadrado(int posicionX, int posicionY) {
    rlutil::setColor(rlutil::WHITE);
    for (int x = posicionX; x <= posicionX + 6; x++) {
        for (int y = posicionY; y <= posicionY + 2; y++) {
            rlutil::locate(x, y);
            cout << (char)219;
        }
    }
}

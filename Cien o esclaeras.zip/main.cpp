#include <iostream>
#include "rlutil.h"
#include <ctime>
#include "menu.h"
#include "juego.h"

using namespace std;

int main(){
	int opcion;
	///Agregue el srand para que los dados den random
	srand(time(0));

	do{
        rlutil::cls();

		opcion = seleccionarOpcion();

		ejecutarOpcion(opcion);

		system("pause");
	} while (opcion !=4);
	return 0;
}

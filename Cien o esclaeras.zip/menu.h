#pragma once

int seleccionarOpcion();
void ejecutarOpcion(int opcion);

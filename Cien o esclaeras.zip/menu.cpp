#include <iostream>
#include "menu.h"
#include "juego.h"
#include "rlutil.h"
using namespace std;


int seleccionarOpcion() {
    int opcion;
	cout << "--- Menu Principal ---" << endl;
	cout << "1. Juego nuevo para un jugador" << endl;
	cout << "2. Juego nuevo para dos jugadores" << endl;
	cout << "3. Mostrar puntuacion mas alta" << endl;
	cout << "4. Salir" << endl;

    cout << "Seleccione una opcion: ";
    cin >> opcion;

    return opcion;
}


void ejecutarOpcion (int opcion) {
    switch (opcion) {
		case 1:
            system("cls");
			unJugador();
			system("pause");
			break;
		case 2:
		    system("cls");

		    system("pause");
			break;
		case 3:
		    system("cls");
		    mostrarPuntuacionAlta();

			break;
		case 4:
		    system("cls");
			cout << "Gracias por jugar a nuestro juego :)" << endl;

			break;
		default:
			cout << "Opcion no valida. Intente de nuevo" << endl;
		}
}

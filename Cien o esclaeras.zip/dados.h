#pragma once

//declaracion de funciones
void dibujarCuadrado(int posicionX, int posicionY); //separar los parametros
void dibujarDado (int dados, int posicionX, int posicionY);
void dibujarSombra (int posicionX, int posicionY);
void dibujarPuntos (int dados, int posicionX, int posicionY);
void lanzarYDibujarDados(int dados[], int posicionX, int posicionY);

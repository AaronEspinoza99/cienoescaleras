#pragma once

void unJugador();
void mostrarPuntuacionAlta();

int calcularPuntaje();
void actualizarPuntuacionAlta();

